
<?php $__env->startSection('title', 'Edit Kontak | Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="fw-bold mb-3">Edit Kontak</h2>
    <form action="<?php echo e(route('kontaks.update', $kontak)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e($kontak->email); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Telepon</label>
            <input type="text" name="phone" class="form-control" value="<?php echo e($kontak->phone); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Alamat</label>
            <input type="text" name="address" class="form-control" value="<?php echo e($kontak->address); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Instagram</label>
            <input type="text" name="instagram" class="form-control" value="<?php echo e($kontak->instagram); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Facebook</label>
            <input type="text" name="facebook" class="form-control" value="<?php echo e($kontak->facebook); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">LinkedIn</label>
            <input type="text" name="linkedin" class="form-control" value="<?php echo e($kontak->linkedin); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">YouTube</label>
            <input type="text" name="youtube" class="form-control" value="<?php echo e($kontak->youtube); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">TikTok</label>
            <input type="text" name="tiktok" class="form-control" value="<?php echo e($kontak->tiktok); ?>">
        </div>
        <button class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('kontaks.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
    <a href="<?php echo e(route('admin-dashboard')); ?>" class="btn btn-outline-dark mb-3">Kembali ke Dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fariz\Downloads\Himakom\Himakom\resources\views/admin/kontaks/edit.blade.php ENDPATH**/ ?>